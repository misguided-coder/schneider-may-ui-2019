
function greet(name) {
	document.write(`Hi : ${name}`);
	document.write("<br/>");	
}

function greetMe(name) {
	document.write(`Hello : ${name}`);
	document.write("<br/>");	
}


function greetYou(name) {
	document.write(`Good Morning : ${name}`);
	document.write("<br/>");	
}


function greetGuest(name) {
	document.write(`Good Evening : ${name}`);
	document.write("<br/>");	
}

//greet('Raj');


//Developer 1 -- function designer
function showNames(arg) {
	var names = ['Jaggu','Pintu','Ghanshu','Chandu']; 

	document.write("Preparing.....");
	document.write("<br/>");	

	for(var name of names) {
		//greet(name);
		arg(name);
	}

	document.write("Done....");
	document.write("<br/>");	
}	