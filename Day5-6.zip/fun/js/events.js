$(() => {
	//var array = $('#btn0');
	var array = $('input');
	array.bind('click',sayHello);			 	
	console.log(`All Events registered on Page Load!!!!!!`);
});

function sayHello(){
	console.log(`Hello.....`);
}
